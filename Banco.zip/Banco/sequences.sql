create sequence seq_auditoria;
create sequence seq_noticias;
create sequence seq_categoria;
create sequence seq_pessoa;
